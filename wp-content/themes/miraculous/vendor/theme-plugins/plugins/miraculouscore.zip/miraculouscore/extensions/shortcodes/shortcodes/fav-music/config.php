<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Favourites Tracks', 'miraculous'),
        'description'   => __('Add Tracks', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-heart',
        'popup_size'    => 'small', 
    )
);
?>