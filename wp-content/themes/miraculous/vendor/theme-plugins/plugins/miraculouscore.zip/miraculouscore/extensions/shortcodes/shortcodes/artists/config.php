<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Artists', 'miraculous'),
        'description'   => __('Add Artists', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-microphone',
        'popup_size'    => 'small', // can be large, medium or small
    )
);
?>