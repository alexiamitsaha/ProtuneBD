<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'upload_heading_one'   => array(
        'label'   => __('Heading 1', 'miraculous'),
        'type'    => 'text'
    ),
    'upload_heading_two'   => array(
        'label'   => __('Heading 2', 'miraculous'),
        'type'    => 'text'
    ),
    'upload_heading_three'   => array(
        'label'   => __('Heading 3', 'miraculous'),
        'type'    => 'text'
    ),
);
?>