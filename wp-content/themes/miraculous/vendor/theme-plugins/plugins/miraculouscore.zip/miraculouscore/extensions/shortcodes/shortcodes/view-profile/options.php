<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'profile_heading'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'text'
    ),
    'user_setting_page'   => array(
        'label'   => __('Edit profile button URL', 'miraculous'),
        'type'    => 'text'
    ),
);
?>