<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('User Playlist', 'miraculous'),
        'description'   => __('User Playlist', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-list',
        'popup_size'    => 'small', 
    )
);
?>