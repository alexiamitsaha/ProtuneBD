<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'history_heading'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'text'
    ),
    'number_limits'   => array(
        'label'   => __('Number of Songs', 'miraculous'),
        'type'    => 'text'
    ),
);