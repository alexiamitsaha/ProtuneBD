<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Download Tracks', 'miraculous'),
        'description'   => __('Download Tracks', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-music',
        'popup_size'    => 'small', 
    )
);
?> 