<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$cfg = array();
$cfg['page_builder'] = array(
	'title'       => esc_html__('Slider', 'miraculous'),
	'description' => esc_html__('Revolution Slider Section', 'miraculous'),
	'tab'         => esc_html__('Miraculous Elements', 'miraculous'),
    'icon'  =>'fa fa-sliders',  
     );  