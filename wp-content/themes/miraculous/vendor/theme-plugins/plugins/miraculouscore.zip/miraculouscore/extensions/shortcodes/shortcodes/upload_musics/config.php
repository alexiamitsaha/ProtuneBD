<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Free Tracks Upload', 'miraculous'),
        'description'   => __('Free Tracks Upload', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-cloud-upload',
        'popup_size'    => 'small',
    )
);
?>