<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'user_music_label'   => array(
        'label'   => __('Label', 'miraculous'),
        'type'    => 'text'
    ),
   
);
?>