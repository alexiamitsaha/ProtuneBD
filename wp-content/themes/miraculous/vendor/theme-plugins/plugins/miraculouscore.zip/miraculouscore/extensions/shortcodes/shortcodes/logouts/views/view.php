<?php if (!defined('FW')) die('Forbidden');
?>
<a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>" class="ms_btn"><?php esc_html_e('Logout Here','miraculous'); ?></a>

