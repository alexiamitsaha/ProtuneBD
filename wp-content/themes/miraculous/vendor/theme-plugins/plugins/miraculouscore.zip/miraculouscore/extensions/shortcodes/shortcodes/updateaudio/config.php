<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Update Audio', 'miraculous'),
        'description'   => __('Update Audio', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-cloud-upload',
        'popup_size'    => 'small',
    )
);
?> 