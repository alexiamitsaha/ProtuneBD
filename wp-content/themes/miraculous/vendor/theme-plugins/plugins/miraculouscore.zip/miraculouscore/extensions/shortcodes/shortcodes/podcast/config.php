<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Podcast', 'miraculous'),
        'description'   => __('Add Podcast', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-film',
        'popup_size'    => 'small', // can be large, medium or small
    )
);
?>