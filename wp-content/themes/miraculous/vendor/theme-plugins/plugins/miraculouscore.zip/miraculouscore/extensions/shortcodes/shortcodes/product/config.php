<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Product', 'miraculous'),
        'description'   => __('WooCommerce Product', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-cart-arrow-down',
        'popup_size'    => 'small', 
    )
);
?>