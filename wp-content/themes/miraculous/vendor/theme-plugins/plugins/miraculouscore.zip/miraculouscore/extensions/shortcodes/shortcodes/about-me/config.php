<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('About Me', 'miraculous'),
        'description'   => __('About Me', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-user-circle',
        'popup_size'    => 'small',
       )
    );
?>