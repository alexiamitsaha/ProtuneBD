<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Notification', 'miraculous'),
        'description'   => __('Show Artist And Listner Notification', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-heart',
        'popup_size'    => 'small', 
    )
);
?>