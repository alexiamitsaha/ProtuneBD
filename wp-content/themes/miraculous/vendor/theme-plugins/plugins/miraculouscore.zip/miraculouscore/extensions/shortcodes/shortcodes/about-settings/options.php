<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'profile_heading'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'text'
    ),
);
?>