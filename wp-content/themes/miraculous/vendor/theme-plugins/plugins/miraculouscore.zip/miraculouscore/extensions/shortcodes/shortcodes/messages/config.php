<?php if ( ! defined( 'FW' ) ):
	die( 'Forbidden' );
endif;
$cfg = array();
$cfg['page_builder'] = array(
	'title'       => esc_html__('Messages', 'miraculous'),
	'description' => esc_html__('Messages', 'miraculous'),
	'tab'           => __('Miraculous Elements', 'miraculous'),
    'icon'  =>'fa fa-pencil-square-o',  
);    