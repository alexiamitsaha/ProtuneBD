<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('My Artist', 'miraculous'),
        'description'   => __('My Artist', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-comment',
        'popup_size'    => 'small', 
    )
);
?>