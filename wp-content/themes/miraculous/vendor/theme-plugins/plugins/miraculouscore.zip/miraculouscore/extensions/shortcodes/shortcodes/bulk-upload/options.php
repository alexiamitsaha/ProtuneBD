<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'bulk_upload_label'   => array(
        'label'   => __('Label', 'miraculous'),
        'help'    => __('help', 'miraculous'),
        'type'    => 'text'
    ),
    'bulk_upload_hint'   => array(
        'label'   => __('Hint Text', 'miraculous'),
        'help'    => __('help', 'miraculous'),
        'type'    => 'text'
    ),
    'bulk_upload_button'   => array(
        'label'   => __('Button Text', 'miraculous'),
        'help'    => __('help', 'miraculous'),
        'type'    => 'text'
    ),
    'bulk_upload_succes'   => array(
        'label'   => __('Succes Message', 'miraculous'),
        'help'    => __('help', 'miraculous'),
        'type'    => 'text'
    ),
);
?>