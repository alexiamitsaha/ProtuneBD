<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'upload_heading'   => array(
        'label'   => __('Heading', 'miraculous'),
        'type'    => 'text'
    ),
);
?> 