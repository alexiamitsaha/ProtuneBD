<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('User Earning', 'miraculous'),
        'description'   => __('User Earning', 'miraculous'),
        'tab'           => __('Miraculous Vendor Elements', 'miraculous'),
        'icon' => 'fa fa-usd',
        'popup_size'    => 'small',
       )
    ); 
?>