<?php if (!defined('FW')) die('Forbidden');
$options = array(
    'upload_heading_one'   => array(
        'label'   => __('Heading 1', 'miraculous'),
        'type'    => 'text'
    ),
);
?> 