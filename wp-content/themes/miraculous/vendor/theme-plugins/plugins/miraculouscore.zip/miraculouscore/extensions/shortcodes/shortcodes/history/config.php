<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('History', 'miraculous'),
        'description'   => __('Show History', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-history',
        'popup_size'    => 'small', 
    )
);
?>