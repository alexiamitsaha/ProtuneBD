<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Track Upload With Price Option', 'miraculous'),
        'description'   => __('Track Upload With Price Option', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-cloud-upload',
        'popup_size'    => 'small',
    )
); 
?>