<?php if (!defined('FW')) die('Forbidden');
$cfg = array(
    'page_builder' => array(
        'title'         => __('Tracks Filter', 'miraculous'),
        'description'   => __('Filter Tracks by thier views or downloads', 'miraculous'),
        'tab'           => __('Miraculous Elements', 'miraculous'),
        'icon' => 'fa fa-headphones',
        'popup_size'    => 'small', 
    )
);
?>